//
//  LGPerson.m
//  LGTest
//
//  Created by cooci on 2019/2/15.
//

#import "LGPerson.h"

@implementation LGPerson

@end
