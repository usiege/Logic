//
//  LGPerson.h
//  LGTest
//
//  Created by cooci on 2019/2/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LGPerson : NSObject
@property (nonatomic, copy) NSString *name;
@property (nonatomic, assign) int age;

@end

NS_ASSUME_NONNULL_END
